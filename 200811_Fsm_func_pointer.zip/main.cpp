// 
// Explain: �Լ� ������

#include <stdio.h>
#include <windows.h>
#include <memory.h>


enum EFsm
{
	AI_IDLE		=0,
	AI_WALK		,
	AI_RUN		,
	AI_ATTACK	,

	AI_TOT		,
};

class Cfsm
{
private:
	//	int	 (Cfsm::*OnAiPtr	[AI_TOT])(char*);
	int (Cfsm::**OnAiPtr)(char*);

	int AiIdle(char* pParam)	{	return printf("Ai Idle:%s\n", pParam);	}
	int AiWalk(char* pParam)	{	return printf("Ai Walk:%s\n", pParam);	}
	int AiRun(char* pParam)		{	return printf("Ai Run:%s\n", pParam);	}
	int AiAttack(char* pParam)	{	return printf("Ai Attack:%s\n", pParam);	}


public:
	Cfsm()
	{
		// int	 (Cfsm::*OnAiPtr   [ AI_TOT])(char*);
		// ���� �̺κ��� �������� �Ҵ��Ѵٸ�
		OnAiPtr = new (int (Cfsm::*[ AI_TOT])(char*));

		OnAiPtr[0] = AiIdle;
		OnAiPtr[1] = AiWalk;
		OnAiPtr[2] = AiRun;
		OnAiPtr[3] = AiAttack;
	}

	virtual ~Cfsm()
	{
		if(OnAiPtr)
		{
			delete [] OnAiPtr;
			OnAiPtr = NULL;
		}
	}

	
	void OnAiPrc(int nIdx, char* pParam)
	{
		(this->*OnAiPtr[nIdx])(pParam);
	}
};





int main()
{
	printf("�Լ� ������+ fsm\n\n");

	Cfsm	pCls;
	INT		nFsm = -1;

	nFsm = AI_IDLE;
	pCls.OnAiPrc(nFsm, "Ai String Command1");

	nFsm = AI_ATTACK;
	pCls.OnAiPrc(nFsm, "Ai String Command2");

	nFsm = AI_WALK;
	pCls.OnAiPrc(nFsm, "Ai String Command3");

	nFsm = AI_RUN;
	pCls.OnAiPrc(nFsm, "Ai String Command4");

	
	return 1;
}