A* Algorithm by Justin Heyes-Jones

This implementation is intended to be simple to read yet fairly
efficient. To build it you can compile, with any recent C++ compiler,
the following files :

For 8-puzzle solver

	8puzzle.cpp
	stlastar.h
	optionally fsa.h

Command line 

	8puzzle with no arguments runs with one of the boards in the cpp file, you can
	select the one you want changing the conditional compiliation instructions. Or if you
	prefer pass in a board on the command line using digits for the tile positions, where
	zero is the space. The board runs from left to right, each row at a time:
	
		8puzzle 013824765

For path finder 

	findpath.cpp
	stlastar.h
	optionally fsa.h

	pathfind has no arguments. You can edit the simple map in pathfind.cpp and the start 
	and goal co-ordinates to experiement with the pathfinder.

Fixed size allocator notes: As mentioned briefly in the tutorial you can enable and disable the
faster memory allocation. This allocates a fixed size block of memory, so you have to specify this size
with the astar constructor. You need to enlarge it if you hit an out of memory assert during the
search.

Compilation notes:

Visual C++ 5 SP3 : You need to download a different STL implementation. I used SGI's at www.sgi.com/stl
Visual C++ 6 SP4 : No problems
GCC notes : Compiled using version 2.91.66 No problems

If you have problems I would download the Silicon Graphics or STLPort version of STL and try
that. Failing that mail me at :


History:

Updated November 26th 2001

	Fixed a bug. When a node is deleted from the Open list I did sort_heap when make_heap
	is needed to keep the heap structure valid. This causes the search to go awry under some
	conditions. Thanks to Mike Ryynanen for tracking this down.

justinhj@hotmail.com

http://www.geocities.com/jheyesjones/astar.html

Justin Heyes-Jones


