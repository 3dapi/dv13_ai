// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable: 4786)

#include <set>
#include <vector>
#include <list>

using namespace std;


#include "_StdAfx.h"


#define MAX_LEN		0xFFFFFFFF
#define TILE_LEN	30


int	bMap[TILE_LEN][TILE_LEN]	=
{
	//	0	1	2	3	4	5	6	7	8	9		10	11	12	13	14	15	17	18	19		20	21	22	23	24	25	26	27	28	29
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	0
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	1
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	2
	{	0,	0,	0,	0,	0,	4,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	3
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	4
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	5
	{	0,	4,	4,	4,	4,	4,	4,	4,	4,	0,		4,	0,	4,	4,	0,	4,	4,	4,	4,		4,	4,	4,	4,	0,	4,	0,	4,	4,	4,	},	//	6
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	7
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	8
	{	0,	0,	0,	0,	4,	0,	4,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	9

	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	10
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	11
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	12
	{	0,	0,	0,	0,	4,	0,	4,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	13
	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	4,		4,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	14
	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	15
	{	0,	4,	4,	4,	4,	4,	4,	4,	4,	0,		4,	0,	4,	4,	4,	4,	0,	0,	4,		4,	4,	4,	4,	4,	4,	0,	4,	4,	4,	},	//	16
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	17
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	18
	{	0,	0,	0,	0,	4,	4,	0,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	19

	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	20
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	4,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	21
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	22
	{	0,	0,	0,	4,	4,	4,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	23
	{	0,	0,	0,	4,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	24
	{	0,	0,	0,	4,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	25
	{	0,	4,	4,	4,	0,	0,	4,	4,	4,	0,		4,	0,	4,	4,	4,	4,	4,	4,	4,		4,	4,	4,	4,	0,	4,	0,	4,	4,	4,	},	//	26
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	27
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	28
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	29
};


int	g_nBgnY	= 25;
int g_nBgnX	= 4;

int	g_nEndY	= 4;
int g_nEndX	= 26;


struct Tile
{
public:
	int		nX;
	int		nY;
	DWORD	bWall;

protected:
	DWORD	dL;
	DWORD	dG;
	DWORD	dH;

	int		nPrnX;
	int		nPrnY;

public:
	Tile()
	{
		Init();
	}

	void	Init()
	{
		nX		= -1;
		nY		= -1;
		bWall	= 0;

		dL		= MAX_LEN;
		dH		= MAX_LEN;
		dG		= MAX_LEN;

		nPrnX	= -1;
		nPrnY	= -1;
	}

	void	SetParent(INT X,INT Y)
	{
		nPrnX	= X;
		nPrnY	= Y;
	}

	INT		GetParentX()	{		return nPrnX;	}
	INT		GetParentY()	{		return nPrnY;	}
	DWORD	GetLength()		{		return dL;		}
	DWORD	GetWeight()		{		return dG;		}
	DWORD	GetHuristic()	{		return dH;		}

	void	SetWeight(DWORD L, INT X, INT Y)
	{
		dL	= L;

		X = abs(nX - X);
		Y = abs(nY - Y);

//		{
//			INT Min	= min(X, Y);
//			INT Max	= max(X, Y);
//			dH	=141*Min + 100 * (Max-Min);
//		}
//
		{
//			dH	= X*X + Y*Y;
//			dH	=sqrtf(dH);
//			dH *=100;

			dH	= X + Y;
			dH	*=100;
		}

		dG	= dL + dH;
	}
};


typedef vector<Tile* >		lsTile;
typedef lsTile::iterator	itTile;

Tile		g_Tile[TILE_LEN][TILE_LEN];
lsTile		g_vTile;

vector<Tile*>		g_vPath;


CMain::CMain()
{
	m_pLcSprite	= NULL;
	m_pInput	= NULL;
	m_pD3DXFont	= NULL;

	m_pTxBlc	= NULL;
}


HRESULT CMain::Init()
{
	HRESULT hr=0;

	m_pLcSprite = new CLcSprite;
	if(FAILED(m_pLcSprite->Create(m_pd3dSprite)))
		return -1;

	m_pInput = new CLcInput;
	if( FAILED(m_pInput->Create(m_hWnd)))
		return -1;

	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "����ü"
	};

	D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pD3DXFont);



	m_pTxBlc	= new CLcTexture;
	if( FAILED(m_pTxBlc->Create(m_pd3dDevice, "Texture/Block.png", 0x00)))
		return -1;


	return 0;
}


HRESULT CMain::Destroy()
{
	SAFE_DELETE(	m_pLcSprite	);
	SAFE_DELETE(	m_pInput	);
	SAFE_RELEASE(	m_pD3DXFont	);

	SAFE_DELETE(	m_pTxBlc	);

	return 0;
}


HRESULT CMain::Restore()
{
	m_pD3DXFont->OnResetDevice();

	return 0;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	return 0;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRMMOV(	m_pInput	);

	INT		nBgnX = g_nBgnX;
	INT		nBgnY = g_nBgnY;

	INT		nEndX = g_nEndX;
	INT		nEndY = g_nEndY;


	if(m_pInput->KeyDown(VK_DOWN))
	{
		++nEndY;

		if(nEndY<TILE_LEN)
		{
			if(! bMap[nEndY][g_nEndX])
				g_nEndY =nEndY;
		}
	}

	if(m_pInput->KeyDown(VK_UP))
	{
		--nEndY;

		if(nEndY>=0)
		{
			if(! bMap[nEndY][g_nEndX])
				g_nEndY =nEndY;
		}
	}

	if(m_pInput->KeyDown(VK_LEFT))
	{
		--nEndX;

		if(nEndX>=0)
		{
			if(! bMap[g_nEndY][nEndX])
				g_nEndX =nEndX;
		}
	}

	if(m_pInput->KeyDown(VK_RIGHT))
	{
		++nEndX;

		if(nEndX<TILE_LEN)
		{
			if(! bMap[g_nEndY][nEndX])
				g_nEndX =nEndX;
		}
	}




	if(m_pInput->KeyDown('S'))
	{
		++nBgnY;

		if(nBgnY<TILE_LEN)
		{
			if(! bMap[nBgnY][g_nBgnX])
				g_nBgnY =nBgnY;
		}
	}

	if(m_pInput->KeyDown('W'))
	{
		--nBgnY;

		if(nBgnY>=0)
		{
			if(! bMap[nBgnY][g_nBgnX])
				g_nBgnY =nBgnY;
		}
	}

	if(m_pInput->KeyDown('A'))
	{
		--nBgnX;

		if(nBgnX>=0)
		{
			if(! bMap[g_nBgnY][nBgnX])
				g_nBgnX =nBgnX;
		}
	}

	if(m_pInput->KeyDown('D'))
	{
		++nBgnX;

		if(nBgnX<TILE_LEN)
		{
			if(! bMap[g_nBgnY][nBgnX])
				g_nBgnX =nBgnX;
		}
	}


	DWORD	dBgn = timeGetTime();
	INT		nTurn = 100;

	for(int i=0; i<nTurn; ++i)
		PathFinding();

	DWORD	dEnd = timeGetTime();

	m_fPathTime = FLOAT(dEnd - dBgn)*20/FLOAT(nTurn);

	return 0;
}


HRESULT CMain::Render()
{
	int	i, j;

	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,120,160), 1.0f, 0 );

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;



	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			D3DXCOLOR	color(1,1,1,1);
			if(bMap[j][i])
			{
				color	= D3DXCOLOR(1,1,0,1);

				m_pLcSprite->Draw(
					  m_pTxBlc->GetTexture()
					, &m_pTxBlc->GetImageRect()
					, NULL
					, NULL
					, 0
					, &D3DXVECTOR2( i*20, j*20)
					, color);
			}
			else
			{
				color	= D3DXCOLOR(0,1,1,1);
			}


		}
	}




	int iSize = g_vPath.size();

	for(i=0; i<iSize; ++i)
	{
		m_pLcSprite->Draw(m_pTxBlc->GetTexture()
					, &m_pTxBlc->GetImageRect()
					, NULL
					, NULL
					, 0
					, &D3DXVECTOR2(g_vPath[i]->GetParentX()*20, g_vPath[i]->GetParentY()*20)
					, 0Xffff00ff);
	}


	m_pLcSprite->Draw(m_pTxBlc->GetTexture()
				, &m_pTxBlc->GetImageRect()
				, NULL
				, NULL
				, 0
				, &D3DXVECTOR2(g_nEndX*20, g_nEndY*20)
				, 0Xff00ff00);

	m_pLcSprite->Draw(m_pTxBlc->GetTexture()
				, &m_pTxBlc->GetImageRect()
				, NULL
				, NULL
				, 0
				, &D3DXVECTOR2(g_nBgnX*20, g_nBgnY*20)
				, 0XFFFF0000);

	char	sMsg[1024]={0};
	RECT	rc;

	SetRect(&rc, 5, 550, m_dScnW-10, 570);
	sprintf(sMsg, "PathFinding Time: %f", m_fPathTime);
	m_pD3DXFont->DrawText(NULL, sMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1));

	SetRect(&rc, 5, 570, m_dScnW-10, 590);
	sprintf(sMsg, "FPS: %.f", m_fFps);
	m_pD3DXFont->DrawText(NULL, sMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1));


	m_pd3dDevice->EndScene();

	return 0;
}


LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	if(m_pInput)
		m_pInput->MsgProc(hWnd, msg, wParam, lParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			break;
		}
	}

	return CD3DApp::MsgProc( hWnd, msg, wParam, lParam );
}




void CMain::PathFinding()
{
	int i, j;
	int	bFind	= FALSE;

	// �� �Ӽ� �ο�
	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			g_Tile[j][i].Init();

			g_Tile[j][i].nY	 = j;
			g_Tile[j][i].nX	 = i;
			g_Tile[j][i].bWall = bMap[j][i];
		}
	}


	g_Tile[g_nBgnY][g_nBgnX].SetWeight(0, g_nEndX, g_nEndY);
	g_Tile[g_nBgnY][g_nBgnX].SetParent(g_nBgnX,  g_nBgnY);


	g_vTile.clear();

	// ���� ���� ���Ϳ� �ִ´�.
	g_vTile.push_back(&g_Tile[g_nBgnY][g_nBgnX]);


	int		iSize = 0;
	
	while( !g_vTile.empty() && FALSE == bFind)
	{
		int nMinW	= MAX_LEN;
		int nMinX	= -1;
		int	nMinY	= -1;

		itTile	it= NULL;

		itTile	_F= g_vTile.begin();
		itTile	_L= g_vTile.end();


		// Ž�� Huristic+ Length�� ���� �ּ��� ������ ã�´�.
		for(; _F != _L; ++_F)
		{
			DWORD	dW = (*_F)->GetWeight();

			if( dW < nMinW)
			{
				nMinW	= dW;
				nMinX	= (*_F)->nX;
				nMinY	= (*_F)->nY;
				it	= _F;
			}
		}

		// ������ ã�� ������ �����Ѵ�.
		g_vTile.erase(it);


		bFind = FindMinNode(&g_vTile, nMinX, nMinY);
		
	}



	Tile* pTileE	= &g_Tile[g_nEndY][g_nEndX];
	Tile* pTileB	= NULL;


	int nPreY = pTileE->GetParentY();
	int nPreX = pTileE->GetParentX();

	pTileB = &g_Tile[nPreY][nPreX];

	g_vPath.clear();

	g_vPath.push_back(pTileE);
	g_vPath.push_back(pTileB);

	while (TRUE)
	{
		if(nPreY == g_nBgnY &&
		   nPreX == g_nBgnX)
		{
			break;
		}

		int nTy = nPreY;
		int nTx = nPreX;

		pTileB = &g_Tile[nTy][nTx];

		nPreY = pTileB->GetParentY();
		nPreX = pTileB->GetParentX();

		pTileB = &g_Tile[nPreY][nPreX];

		g_vPath.push_back(pTileB);
	}
}



BOOL CMain::FindMinNode(void* pList, INT nMinX, INT nMinY)
{
	BOOL	bFind	= FALSE;

	Tile*	pTileP = &g_Tile[nMinY][nMinX];		// Parent Tile
	Tile*	pTileC = NULL;						// Child Tile


	DWORD	tLen	= pTileP->GetLength();
	DWORD	nMinW	= pTileP->GetWeight();


	lsTile	vTileT;
	lsTile*	vTileP = (lsTile*)pList;

	// ������ ��忡 ���̸� �Ҵ��Ѵ�
	for(int n=-1; n<=1; ++n)
	{
		for(int m=-1; m<=1; ++m)
		{
			if(0==n && 0==m)
				continue;

			if( nMinY+n >=0				&&
				nMinY+n	<TILE_LEN		&&

				nMinX+m >=0				&&
				nMinX+m	<TILE_LEN)
			{

				pTileC = &g_Tile[nMinY+n][nMinX+m];

				if(pTileC->bWall)
					continue;

				DWORD	dL	= 0;
				int		w		= abs(n) + abs(m);

				if( 2 == w)
					dL	= 141;
				else if( 1 == w)
					dL	= 100;

				dL += tLen;

				if(dL < pTileC->GetLength())
				{
					pTileC->SetParent(nMinX, nMinY);
					pTileC->SetWeight(dL, g_nEndX, g_nEndY);

					vTileT.push_back(pTileC);
				}

				if(	nMinY+n == g_nEndY &&
					nMinX+m == g_nEndX)
				{
					bFind	= TRUE;
					break;
				}
			}
		}
	}



	itTile	it= NULL;
	itTile	_F= vTileT.begin();
	itTile	_L= vTileT.end();
	BOOL	bChild=FALSE;


	// Ž�� Huristic+ Length�� ���� �ּ��� ������ ã�´�.
	for(; _F != _L; ++_F)
	{
		DWORD	dW = (*_F)->GetWeight();

		if( dW <= nMinW)
		{
			nMinW	= dW;
			nMinX	= (*_F)->nX;
			nMinY	= (*_F)->nY;
			it	= _F;
		}
	}

	if(it)
	{
		vTileT.erase(it);
		bChild	= TRUE;
	}

	_F= vTileT.begin();
	_L= vTileT.end();

	for(; _F != _L; ++_F)
	{
		vTileP->push_back( *_F);
	}

	vTileT.clear();

	if(bChild && FALSE ==bFind)
	{
		bFind = FindMinNode(pList, nMinX, nMinY);
	}

	return bFind;
}