
#pragma warning(disable: 4786)

#include <set>
#include <vector>

using namespace std;

#include <windows.h>
#include <stdio.h>
#include <math.h>


#define MAX_LEN		0xFFFFFFFF
#define TILE_LEN	30


int	bMap[TILE_LEN][TILE_LEN]	=
{
	//	0	1	2	3	4	5	6	7	8	9		10	11	12	13	14	15	17	18	19		20	21	22	23	24	25	26	27	28	29
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	0
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	1
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	2
	{	0,	0,	0,	0,	0,	4,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	3
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	4
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	5
	{	0,	4,	4,	4,	4,	4,	4,	4,	4,	0,		4,	0,	4,	4,	0,	4,	4,	4,	4,		4,	4,	4,	4,	0,	4,	0,	4,	4,	4,	},	//	6
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	7
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	8
	{	0,	0,	0,	0,	4,	0,	4,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	9

	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	10
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	11
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	12
	{	0,	0,	0,	0,	4,	0,	4,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	13
	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	4,		4,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	14
	{	0,	0,	0,	0,	4,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	15
	{	0,	4,	4,	4,	4,	4,	4,	4,	4,	0,		4,	0,	4,	4,	4,	4,	0,	0,	4,		4,	4,	4,	4,	4,	4,	0,	4,	4,	4,	},	//	16
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	17
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	18
	{	0,	0,	0,	0,	4,	4,	0,	0,	0,	4,		0,	0,	4,	0,	0,	0,	0,	0,	4,		0,	4,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	19

	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	0,	0,	0,	},	//	20
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	4,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	21
	{	0,	0,	0,	0,	0,	4,	0,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	22
	{	0,	0,	0,	4,	4,	4,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		4,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	23
	{	0,	0,	0,	4,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	24
	{	0,	0,	0,	4,	0,	0,	4,	0,	0,	0,		0,	0,	0,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	25
	{	0,	4,	4,	4,	0,	0,	4,	4,	4,	0,		4,	0,	4,	4,	4,	4,	4,	4,	4,		4,	4,	4,	4,	0,	4,	0,	4,	4,	4,	},	//	26
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	27
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	0,		0,	0,	4,	0,	0,	0,	0,	0,	0,		0,	4,	0,	0,	0,	0,	0,	4,	0,	0,	},	//	28
	{	0,	0,	0,	0,	0,	0,	4,	0,	0,	4,		0,	0,	0,	0,	0,	0,	0,	0,	4,		0,	0,	0,	0,	4,	0,	0,	4,	0,	0,	},	//	29
};


int	g_nBgnY	= 25;
int g_nBgnX	= 4;

int	g_nEndY	= 4;
int g_nEndX	= 26;


struct Tile
{
public:
	int		nX;
	int		nY;
	DWORD	bWall;

protected:
	DWORD	dL;
	DWORD	dG;
	DWORD	dH;

	int		nPrnX;
	int		nPrnY;

public:
	Tile()
	{
		nX		= -1;
		nY		= -1;
		bWall	= 0;

		dL		= MAX_LEN;
		dH		= MAX_LEN;
		dG		= MAX_LEN;

		nPrnX	= -1;
		nPrnY	= -1;
	}

	void	SetParent(INT X,INT Y)
	{
		nPrnX	= X;
		nPrnY	= Y;
	}

	INT		GetParentX()	{		return nPrnX;	}
	INT		GetParentY()	{		return nPrnY;	}
	DWORD	GetLength()		{		return dL;		}
	DWORD	GetWeight()		{		return dG;		}

	DWORD	GetHuristic()	{		return dH;		}

	void	SetWeight(DWORD L, INT X, INT Y)
	{
		dL	= L;
		dH	= abs(nX - X) + abs(nY - Y);
		dG	= dL + dH;
	}


};

// For Functor
template<class T>
struct TsrtG																	// For sort... descendent Sort
{
	bool operator()(const T t1,const T t2) const	{ return t1->GetHuristic() < t2->GetHuristic(); }
};


//typedef set<Tile*, TsrtG<Tile* > >	stTile;
typedef set<Tile* >		stTile;

typedef stTile::iterator	itTile;



void main()
{
	int i, j, m, n;
	int	bFind	= FALSE;


	Tile	tile[TILE_LEN][TILE_LEN];

	// �� �Ӽ� �ο�
	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			tile[j][i].nY	 = j;
			tile[j][i].nX	 = i;
			tile[j][i].bWall = bMap[j][i];
		}
	}


	tile[g_nBgnY][g_nBgnX].SetWeight(0, g_nEndX, g_nEndY);
	tile[g_nBgnY][g_nBgnX].SetParent(g_nBgnX,  g_nBgnY);


	stTile	vTile;

	// ���� ���� ���Ϳ� �ִ´�.
	vTile.insert(&tile[g_nBgnY][g_nBgnX]);


	int iSize = 0;

	while( !vTile.empty() && FALSE == bFind)
	{
		int nMin	= MAX_LEN;
		int nMinX	= -1;
		int	nMinY	= -1;

		iSize = vTile.size();
		itTile	it= NULL;

		itTile	_F= vTile.begin();
		itTile	_L= vTile.end();


		// Ž�� Huristic�� ���� �ּ��� ������ ã�´�.
		for(; _F != _L; ++_F)
		{
			DWORD	dW = (*_F)->GetHuristic();

			if( dW < nMin)
			{
				nMin	= dW;
				nMinX	= (*_F)->nX;
				nMinY	= (*_F)->nY;
				it	= _F;
			}
		}

		// Ž�� ���̰� ���� �ּ��� ������ �����Ѵ�.
		vTile.erase(it);

		DWORD tLen = tile[nMinY][nMinX].GetLength();

		// ������ ��忡 ���̸� �Ҵ��Ѵ�
		for(n=-1; n<=1; ++n)
		{
			for(m=-1; m<=1; ++m)
			{
				if(0==n && 0==m)
					continue;

				if( nMinY+n >=0				&&
					nMinY+n	<TILE_LEN		&&

					nMinX+m >=0				&&
					nMinX+m	<TILE_LEN)
				{

					if(tile[nMinY+n][nMinX+m].bWall)
						continue;

					DWORD	dL	= 0;
					int		w		= abs(n) + abs(m);

					if( 2 == w)
						dL	= 141;
					else if( 1 == w)
						dL	= 100;

					dL += tLen;

					if(dL < tile[nMinY+n][nMinX+m].GetLength())
					{
						tile[nMinY+n][nMinX+m].SetParent(nMinX, nMinY);
						tile[nMinY+n][nMinX+m].SetWeight(dL, g_nEndX, g_nEndY);
						vTile.insert(&tile[nMinY+n][nMinX+m]);
					}


					iSize = vTile.size();

					if(nMinY+n == g_nEndY && nMinX+m == g_nEndX)
					{
						bFind	= TRUE;
					}
				}
			}
		}
	}

	FILE*	fp = fopen("resurlt.txt", "wt");

	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			fprintf(fp, "[%4d:%2d %2d]"
						, tile[j][i].GetLength()
						, tile[j][i].GetParentY()
						, tile[j][i].GetParentX()
						);
		}

		fprintf(fp, "\n");
	}


	fprintf(fp, "\n");

	int nPreY = tile[g_nEndY][g_nEndX].GetParentY();
	int nPreX = tile[g_nEndY][g_nEndX].GetParentX();


	vector<Tile* >	vLst;

	vLst.push_back(&tile[g_nEndY][g_nEndX]);

	while (TRUE)
	{
		if(nPreY == g_nBgnY &&
		   nPreX == g_nBgnX)
		{
			break;
		}

		int nTy = nPreY;
		int nTx = nPreX;

		nPreY = tile[nTy][nTx].GetParentY();
		nPreX = tile[nTy][nTx].GetParentX();

		vLst.push_back(&tile[nPreY][nPreX]);
	}


	iSize = vLst.size();

	for(i=iSize-1; i>=0; --i)
	{
		fprintf(fp, "[%4d:%2d %2d]"
					, vLst[i]->GetLength()
					, vLst[i]->GetParentY()
					, vLst[i]->GetParentX()
					);
	}


	fclose(fp);
}
