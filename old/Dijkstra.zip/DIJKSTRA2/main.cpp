
#include <vector>

using namespace std;

#include <windows.h>
#include <stdio.h>
#include <math.h>


#define MAX_LEN		0xFFFFFFFF
#define TILE_LEN	11


int	bMap[TILE_LEN][TILE_LEN]	=
{
	//	0	1	2	3	4	5	6	7	8	9	10
	{	0,	0,	0,	0,	0,	1,	0,	0,	0,	1,	0,	},	//	0
	{	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	0,	},	//	1
	{	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	0,	},	//	2
	{	0,	0,	0,	0,	0,	1,	1,	0,	0,	0,	0,	},	//	3
	{	0,	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	},	//	4
	{	0,	0,	0,	0,	0,	0,	1,	0,	0,	0,	0,	},	//	5
	{	0,	1,	1,	1,	1,	1,	1,	1,	1,	0,	1,	},	//	6
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	7
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	},	//	8
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	1,	0,	},	//	9
	{	0,	0,	0,	0,	0,	0,	0,	0,	0,	1,	0,	},	//	10
};


int g_nBgnX	= 2;
int	g_nBgnY	= 1;

int g_nEndX	= 7;
int	g_nEndY	= 1;


struct Tile
{
	int		nX;
	int		nY;

	DWORD	dLen;
	DWORD	bWall;

	int		nPrnX;
	int		nPrnY;

	Tile()
	{
		nX	= -1;
		nY	= -1;

		dLen	= MAX_LEN;
		nPrnX	= -1;
		nPrnY	= -1;

		bWall	= 0;
	}
};



void main()
{
	int i, j, m, n;
	int	bFind	= FALSE;


	Tile	tile[TILE_LEN][TILE_LEN];

	// �� �Ӽ� �ο�
	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			tile[j][i].nY	 = j;
			tile[j][i].nX	 = i;
			tile[j][i].bWall = bMap[j][i];
		}
	}


	tile[g_nBgnY][g_nBgnX].dLen = 0;
	tile[g_nBgnY][g_nBgnX].nPrnX = g_nBgnX;
	tile[g_nBgnY][g_nBgnX].nPrnY = g_nBgnY;


	vector<Tile* >	vTile;

	// ���� ���� ���Ϳ� �ִ´�.
	vTile.push_back(&tile[g_nBgnY][g_nBgnX]);


	int iSize = 0;

	while( !vTile.empty() && FALSE == bFind)
	{
		int nMin = MAX_LEN;
		int nMinX	= -1;
		int	nMinY	= -1;

		iSize = vTile.size();
		vector<Tile* >::iterator	it= NULL;


		// Ž�� ���̰� ���� �ּ��� ������ ã�´�.
		for(int i=0; i<iSize; ++i)
		{
			if(vTile[i]->dLen<nMin)
			{
				nMin	= vTile[i]->dLen;
				nMinX	= vTile[i]->nX;
				nMinY	= vTile[i]->nY;
				it	= vTile.begin() + i;
			}
		}

		// Ž�� ���̰� ���� �ּ��� ������ �����Ѵ�.
		vTile.erase(it);

		int tLen = tile[nMinY][nMinX].dLen;

		// ������ ��忡 ���̸� �Ҵ��Ѵ�
		for(n=-1; n<=1; ++n)
		{
			for(m=-1; m<=1; ++m)
			{
				if(0==n && 0==m)
					continue;

				if( nMinY+n >=0				&&
					nMinY+n	<TILE_LEN		&&

					nMinX+m >=0				&&
					nMinX+m	<TILE_LEN)
				{

					if(tile[nMinY+n][nMinX+m].bWall)
						continue;

					int	dLen	= 0;
					int w		= abs(n) + abs(m);
					if( 2 == w)
						dLen	= 141;
					else if( 1 == w)
						dLen	= 100;

					dLen += tLen;

					if(dLen < tile[nMinY+n][nMinX+m].dLen)
					{
						tile[nMinY+n][nMinX+m].dLen = dLen;
						tile[nMinY+n][nMinX+m].nPrnX = nMinX;
						tile[nMinY+n][nMinX+m].nPrnY = nMinY;

						vTile.push_back(&tile[nMinY+n][nMinX+m]);
					}

					if(nMinY+n == g_nEndY && nMinX+m == g_nEndX)
					{
						bFind	= TRUE;
					}
				}
			}
		}
	}

	FILE*	fp = fopen("resurlt.txt", "wt");

	for(j=0; j<TILE_LEN; ++j)
	{
		for(i=0; i<TILE_LEN; ++i)
		{
			fprintf(fp, "[%5d:%2d %2d]", tile[j][i].dLen, tile[j][i].nPrnY, tile[j][i].nPrnX);
		}

		fprintf(fp, "\n");
	}


	fprintf(fp, "\n");

	int nPreY = tile[g_nEndY][g_nEndX].nPrnY;
	int nPreX = tile[g_nEndY][g_nEndX].nPrnX;

	while (TRUE)
	{
		if(nPreY == g_nBgnY &&
		   nPreX == g_nBgnX)
		{
			break;
		}

		int nTy = nPreY;
		int nTx = nPreX;


		fprintf(fp, "[%5d:%2d %2d]"
					, tile[nTy][nTx].dLen
					, tile[nTy][nTx].nPrnY
					, tile[nTy][nTx].nPrnX);


		nPreY = tile[nTy][nTx].nPrnY;
		nPreX = tile[nTy][nTx].nPrnX;

	}


	fclose(fp);
}
