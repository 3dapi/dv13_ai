// Interface for the CPathFinder class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _PATHFINDER_H_
#define _PATHFINDER_H_


typedef struct tagImage
{
	PDTX pSurface;																//pointer to the image
	INT imageWidth;
	INT imageHeight;

	tagImage()
	{
		pSurface	= NULL;
	}

	~tagImage()
	{
		SAFE_RELEASE(	pSurface	);
	}

}Image;


class CPathFind
{
public:
	INT		mapX		 ;
	INT		mapZ		 ;
	INT		tileS		 ;
	INT		notfinished	 ;
	INT		notStarted	 ;														// path-related constants
	INT		found		 ;
	INT		nonexistent	 ;
	INT		walkable	 ;
	INT		unwalkable	 ;														// walkability array constants


	INT		drawing;
	INT		erasing;
	INT		startX, startY;														//Set seeker location
	INT		targetX, targetY;													//Set initial target location. This can be changed by right-clicking on the map.

	INT		onClosedList;
	INT		path		;

	char**	walkability	;														//Create needed arrays
	INT*	openList	;														//1 dimensional array holding ID# of open list items
	char**	whichList	;														//2 dimensional array used to record

	INT*	openX		;														//1d array stores the x location of an item on the open list
	INT*	openY		;														//1d array stores the y location of an item on the open list
	INT**	parentX		;														//2d array to store parent of each cell (x)
	INT**	parentY		;														//2d array to store parent of each cell (y)
	INT*	Fcost		;														//1d array to store F cost of a cell on the open list
	INT**	Gcost		;														//2d array to store G cost for each cell.
	INT*	Hcost		;														//1d array to store H cost of a cell on the open list
	INT*	pathBank	;

	INT		pathLength	;														//stores length of the found path for critter
	INT		pathLocation;														//stores current position along the chosen path for critter

	Image*	m_pImPath;
	Image*	m_pImGreen;
	Image*	m_pImRed;
	Image*	m_pImWall;
	
	LPD3DXLINE	m_pLine;

public:
	CPathFind();
	~CPathFind();

	INT		Init();
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();


	INT		FindPath(INT startingX, INT startingY, INT targetX, INT targetY);
	void	ReadPath();

	void	Set();

	INT		DrawBlock(Image* pImage, INT x, INT y);
	Image*	TextureLoad (char* szBitmap);
};

#endif