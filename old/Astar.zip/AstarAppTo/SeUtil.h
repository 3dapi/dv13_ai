// Interface for the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _SEUTIL_H_
#define _SEUTIL_H_

#define ONE_RADtoDEG	57.2957795130823208767981548f
#define ONE_DEGtoRAD	0.01745329251994329576923690f
#define PI				3.14159265358979323846264338f
#define DEG90toRAD		1.57079632679489661923132163f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)

////////////////////////////////////////////////////////////////////////////////
// 

template<class T> D3DXINLINE
bool SeUtil_IsBadReadPtr(T* &t)
{
	return (IsBadReadPtr(t, sizeof(T)));
}


template<class T> D3DXINLINE
bool SeUtil_IsNotAllocated(T* &t)
{
	return (!&t || !t || IsBadReadPtr(t, sizeof(T)) );	
}

template<class T> D3DXINLINE
bool SeUtil_IsAllocated(T* &t)
{
	return !SeUtil_IsNotAllocated(t);
}

template<class T> D3DXINLINE
void SAFE_NEW(T* &p)
{
	//	if(!p)
	if(SeUtil_IsNotAllocated(p))
		p = new T;
}

template<class T> D3DXINLINE
void SAFE_NEW_ARRAY(T* &p, INT N)
{
	if(SeUtil_IsNotAllocated(p))
		p = new T[N];
}

template<class T> D3DXINLINE
INT  _SAFE_NEWINIT(T* &p)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T;
		if( p->Init()<0 )
			return -1;
	}
	
	return 1;
}


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }

#define		SAFE_NEWINIT(p)		if(FAILED(_SAFE_NEWINIT(p)))	return -1;


template<class T> D3DXINLINE
void SAFE_NEWINIT_ARRAY(T* &p, INT N)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T[N];
		for(INT i = 0; i<N ; ++i)
			p[i].Init();
	}
}

#define		SAFE_DESTROY(p)		if(p)	(p)->Destroy();

template<class T> D3DXINLINE
void SAFE_DESTROY_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Destroy();
}

#define		_SAFE_RESTORE(p)	if(p)	(p)->Restore();
#define		SAFE_RESTORE(p)		if((p) && FAILED( (p)->Restore())) return -1;

template<class T> D3DXINLINE
void SAFE_RESTORE_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Restore();
}


#define		SAFE_INVALIDATE(p)	if(p)	(p)->Invalidate();


template<class T> D3DXINLINE
void SAFE_INVALIDATE_ARRAY	(T* &p,INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Invalidate();
}

#define		SAFE_FRAMEMOVE(p)	if( (p) && FAILED( (p)->FrameMove())) return -1;
#define		SAFE_UPDATE(p)		if( (p) && FAILED( (p)->Update())) return -1;


template<class T> D3DXINLINE
void SAFE_FRAMEMOVE_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].FrameMove();
}


#define		SAFE_RENDER(p)	if(p)	(p)->Render();
#define		SAFE_RNDBCK(p)	if(p)	(p)->RndBck();


template<class T> D3DXINLINE
void SAFE_RENDER_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Render();
}


template<class T> D3DXINLINE
void SeUtil_Swap (T* &a, T* &b)
{
	T c; c = *a; *a = *b;*b = c;
}

template<class T> D3DXINLINE void SAFE_INIT_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<p.size; ++i)
		if(p[i])
			p[i]->Init();
}



template<class T> D3DXINLINE
void SAFE_DELETE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DELETE(p[i]);

	p.clear();
}


template<class T> D3DXINLINE
void SAFE_DESTROY_LIST(T &p)
{
	if(p.empty())
		return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DESTROY(p[i]);
}


template<class T> D3DXINLINE
INT SAFE_RESTORE_LIST(T &p)
{
	if(p.empty())
		return -1;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		if((p[i]) && FAILED( (p[i])->Restore()))
			return -1;
	
	return 1;
}


template<class T> D3DXINLINE
void SAFE_INVALIDATE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_INVALIDATE(p[i]);
}




template<class T> D3DXINLINE
INT SAFE_FRAMEMOVE_LIST(T &p)
{
	if(p.empty())
		return 2;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(! p[i])
			return 3;
		
		if( FAILED( (p[i])->FrameMove()))
			return -1;
	}
	
	return 1;
}



template<class T> D3DXINLINE
void SAFE_RENDER_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_RENDER(p[i]);
}

#define		SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}

void	SeUtil_ErrMsgBox(TCHAR *format,...);
void	SeUtil_GetLastError(HWND hWnd);
void	SeUtil_FormatLog(TCHAR *format,...);
void	SeUtil_FormatLog2(TCHAR *format,...);
INT		SeUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color=0xffffffff, D3DXIMAGE_INFO *pSrcInfo=NULL, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), D3DFORMAT d3dFormat = D3DFMT_A8R8G8B8);
void	SeUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr);
void	SeUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');

void	SeUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	SeUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx);
void	SeUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	SeUtil_IBLock(PDIB& pIB, INT nSize, void* pIdx);


bool	SeUtil_LineCross2D(VEC2 * p);
INT		SeUtil_3Dto2D(VEC3 & Out, const VEC3 & In);
bool	SeUtil_PositionMouse3D(VEC3 & vec3dOut);
INT		SeUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	SeUtil_SetWindowTitle(const char *format, ...);
void	SeUtil_TextOut(float x, float y, const char *format, ...);
void	SeUtil_TextOut(VEC2 p, const char *format, ...);
void	SeUtil_OutputDebug(const char *Format, ...);
TCHAR*	SeUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR *sTitle="Choose Folder");
TCHAR*	SeUtil_DWtoStr(DWORD dwA);
char*	SeUtil_Forming(const char *fmt, ...);
char*	getSmallTime(void);
INT		SeUtil_PluckFirstField(char *str, char *dest, INT maxlen, const char *delim);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val);

#endif