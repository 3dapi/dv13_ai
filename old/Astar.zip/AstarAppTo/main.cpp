// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include "SeCommon.h"

CMain* g_pApp  = NULL;

HRESULT CMain::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior, D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
	UNREFERENCED_PARAMETER( dwBehavior );
	UNREFERENCED_PARAMETER( pCaps );
	
	BOOL bCapsAcceptable;
	
	bCapsAcceptable = TRUE;
	
	if( bCapsAcceptable )         
		return S_OK;
	else
		return E_FAIL;
}

INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain d3dApp;
	
	d3dApp.m_hInst =hInst;
	g_pApp  = &d3dApp;
	
	InitCommonControls();
	if( FAILED( d3dApp.Create( hInst ) ) )
		return 0;
	
	return d3dApp.Run();
}




LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	static	WPARAM		wparHi;
	static	WPARAM		wparLo;
	static	HWND		hw;
	
	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);
	hw = (HWND)lParam;

	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				// TODO: change as needed
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
		
	case WM_COMMAND:
		{
			switch(wparLo)
			{
				case ID_VIEW_WIRE:
					m_dwFl = D3DFILL_WIREFRAME;
					break;

				case ID_VIEW_SOLID:
					m_dwFl = D3DFILL_SOLID;
					break;


				case IDM_VIEW_FIELD:
					m_bFld	= !m_bFld;
					break;

			}
			
			
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}


HRESULT CMain::FinalCleanup()
{
	return S_OK;
}


INT_PTR CALLBACK WndAbout(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi;
	WPARAM		wparLo;

	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);	

	switch( uMsg )
	{
		case WM_INITDIALOG:
		{
			return TRUE;
		}
		
		
		case WM_COMMAND:
		{
			switch(wparLo)
			{
			case IDOK:
				{
					SendMessage(hWnd, WM_CLOSE, 0,0);
					break;
				}
			}
			
			break;
		}
		
		
		case WM_CLOSE:
		{
			DestroyWindow(hWnd);
			break;
		}
		
		
	}
	
	return(FALSE);
}