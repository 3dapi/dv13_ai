// Implementation of the CPathFind class.
//
////////////////////////////////////////////////////////////////////////////////


#include "SeCommon.h"


CPathFind::CPathFind()
{
	mapX		 = 107;
	mapZ		 = 80;
	tileS		 = 15;
	notfinished	 = 0;
	notStarted	 = 0;									// path-related constants
	found		 = 1;
	nonexistent	 = 2;
	walkable	 = 0;
	unwalkable	 = 1;										// walkability array constants

	drawing		= 0;
	erasing		= 0;
	startX		= 4;
	startY		= 8;															//Set seeker location
	targetX		= 16;
	targetY		= 9;															//Set initial target location. This can be changed by right-clicking on the map.
	onClosedList= 10;

	walkability	= NULL;
	openList	= NULL;															//1 dimensional array holding ID# of open list items
	whichList	= NULL;															//2 dimensional array used to record
	openX		= NULL;															//1d array stores the x location of an item on the open list
	openY		= NULL;															//1d array stores the z location of an item on the open list
	parentX		= NULL;															//2d array to store parent of each cell (x)
	parentY		= NULL;															//2d array to store parent of each cell (z)
	Fcost		= NULL;															//1d array to store F cost of a cell on the open list
	Gcost		= NULL;															//2d array to store G cost for each cell.
	Hcost		= NULL;															//1d array to store H cost of a cell on the open list
	pathBank	= NULL;

	pathLength	= 0;															//stores length of the found path for critter
	pathLocation= 0;															//stores current position along the chosen path for critter

	m_pImPath	= NULL;
	m_pImGreen	= NULL;
	m_pImRed	= NULL;
	m_pImWall	= NULL;
	m_pLine		= NULL;
}


CPathFind::~CPathFind()
{
	Destroy();
}


INT CPathFind::Init()
{
	m_pImPath	= TextureLoad("Graphics/path.bmp");
	m_pImGreen	= TextureLoad("Graphics/start.bmp");
	m_pImRed	= TextureLoad("Graphics/end.bmp");
	m_pImWall	= TextureLoad("Graphics/wall.bmp");

	Set();

	return 1;
}


void CPathFind::Set()
{
	int i =0;

	path		= 0;
	
	if(walkability)
	{
		for(i=0; i<mapX; ++i)
			SAFE_FREE(	walkability[i]	);
		SAFE_FREE(	walkability	);
	}


	SAFE_FREE(	openList	);
	
	
	if(whichList)
	{
		for(i=0; i<mapX+1; ++i)
			SAFE_FREE(	whichList[i]	);
		SAFE_FREE(	whichList	);
	}

	
	SAFE_FREE(	openX		);
	SAFE_FREE(	openY		);
	

	if(parentX)
	{
		for(i=0; i<mapX; ++i)
			SAFE_FREE(	parentX[i]	);
		SAFE_FREE(	parentX	);
	}

	
	if(parentY)
	{
		for(i=0; i<mapX; ++i)
			SAFE_FREE(	parentY[i]	);
		SAFE_FREE(	parentY	);
	}

	SAFE_FREE(	Fcost	);
	
	if(Gcost)
	{
		for(i=0; i<mapX+1; ++i)
			SAFE_FREE(	Gcost[i]	);
		SAFE_FREE(	Gcost		);
	}
	
	SAFE_FREE(	Hcost		);
	SAFE_FREE(	pathBank	);



	walkability = (char**)	calloc(mapX, sizeof(char*));						//Create needed arrays
	for(i=0; i<mapX; ++i)
		walkability[i] = (char *)	calloc(mapZ, sizeof(char));					//Create needed arrays

	openList	= (INT*)	calloc(mapX*mapZ+2, sizeof(INT));											//1 dimensional array holding ID# of open list items
	
	whichList	= (char**)	calloc(	mapX+1, sizeof(char*));						//2 dimensional array used to record
	for(i=0; i<mapX+1; ++i)
		whichList[i] = (char *)	calloc(mapZ+1, sizeof(char));					//Create needed arrays


	// 		whether a cell is on the open list or on the closed list.

	openX	= (INT*)	calloc(mapX*mapZ+2, sizeof(INT));						//1d array stores the x location of an item on the open list
	openY	= (INT*)	calloc(mapX*mapZ+2, sizeof(INT));						//1d array stores the z location of an item on the open list
	
	parentX	= (INT**)	calloc(mapX+1, sizeof(INT*));
	for(i=0; i<mapX; ++i)
		parentX[i] = (INT*) calloc(mapZ+1, sizeof(INT));						//2d array to store parent of each cell (x)

	parentY	= (INT**)	calloc(mapX+1, sizeof(INT*));
	for(i=0; i<mapX; ++i)
		parentY[i] = (INT*) calloc(mapZ+1, sizeof(INT));						//2d array to store parent of each cell (z)


	Fcost	= (INT*)	calloc(mapX*mapZ+2, sizeof(INT));						//1d array to store F cost of a cell on the open list
	
	Gcost	= (INT**)	calloc(mapX+1, sizeof(INT*));
	for(i=0; i<mapX+1; ++i)
		Gcost[i] = (INT*) calloc(mapZ+1, sizeof(INT));							//2d array to store G cost for each cell.
	
	Hcost	= (INT*)	calloc(mapX*mapZ+2, sizeof(INT));						//1d array to store H cost of a cell on the open list	
}



void CPathFind::Destroy()
{
	int		i;

	SAFE_DELETE(	m_pImPath	);
	SAFE_DELETE(	m_pImGreen	);
	SAFE_DELETE(	m_pImRed	);
	SAFE_DELETE(	m_pImWall	);

	for(i=0; i<mapX; ++i)
		SAFE_FREE(	walkability[i]	);
	SAFE_FREE(	walkability	);


	SAFE_FREE(	openList	);
	
	
	for(i=0; i<mapX+1; ++i)
		SAFE_FREE(	whichList[i]	);
	SAFE_FREE(	whichList	);

	
	SAFE_FREE(	openX		);
	SAFE_FREE(	openY		);
	
	
	for(i=0; i<mapX; ++i)
		SAFE_FREE(	parentX[i]	);
	SAFE_FREE(	parentX	);

	
	for(i=0; i<mapX; ++i)
		SAFE_FREE(	parentY[i]	);
	SAFE_FREE(	parentY	);

	SAFE_FREE(	Fcost	);
		
	for(i=0; i<mapX+1; ++i)
		SAFE_FREE(	Gcost[i]	);
	SAFE_FREE(	Gcost		);
	
	SAFE_FREE(	Hcost		);
	SAFE_FREE(	pathBank	);
}



INT CPathFind::Restore()
{
	D3DXCreateLine(GDEVICE, &m_pLine);

	return 1;
}


void CPathFind::Invalidate()
{
	SAFE_RELEASE(m_pLine);
}


// Name: FindPath
INT CPathFind::FindPath (INT startingX, INT startingY, INT targetX, INT targetY)
{
	INT onOpenList=0, parentXval=0, parentYval=0;
	INT a=0, b=0, m=0, u=0, v=0, temp=0, corner=0, numberOfOpenListItems=0;
	INT addedGCost=0, tempGcost = 0, path = 0, x=0, z=0;
	INT tempx, pathX, pathY, cellPosition;
	INT newOpenListItemID=0;

	//1. Convert location data (in pixels) to coordinates in the walkability array.
	INT startX = startingX/tileS;
	INT startY = startingY/tileS;
	targetX = targetX/tileS;
	targetY = targetY/tileS;

	//2.Quick Path Checks: Under the some circumstances no path needs to
	//	be generated ...

	//	If starting location and target are in the same location...
	if (startX == targetX && startY == targetY && pathLocation > 0)
		return found;

	if (startX == targetX && startY == targetY && pathLocation == 0)
		return nonexistent;

	//	If target square is unwalkable, return that it's a nonexistent path.
	if (walkability[targetX][targetY] == unwalkable)
		goto noPath;

	//3.Reset some variables that need to be cleared
	for (x = 0; x < mapX; ++x)
	{
		for (z = 0; z < mapZ;++z)
			whichList [x][z] = 0;
	}

	onClosedList= 2;															//changing the values of onOpenList and onClosed list is faster than redimming whichList() array
	onOpenList	= 1;
	pathLength	= notStarted;													//i.e, = 0
	pathLocation= notStarted;													//i.e, = 0
	Gcost[startX][startY] = 0;													//reset starting square's G value to 0

	//4.Add the starting location to the open list of squares to be checked.
	numberOfOpenListItems = 1;
	openList[1] = 1;															//assign it as the top (and currently only) item in the open list, which is maintained as a binary heap (explained below)
	openX[1] = startX ; openY[1] = startY;

	//5.Do the following until a path is found or deemed nonexistent.

	while (!GINPUT->KeyState(DIK_ESCAPE))											//Do until path is found or deemed nonexistent
	{
		//6.If the open list is not empty, take the first cell off of the list.
		//	This is the lowest F cost cell on the open list.
		if (numberOfOpenListItems != 0)
		{
			//7. Pop the first item off the open list.
			parentXval = openX[openList[1]];
			parentYval = openY[openList[1]];									//record cell coordinates of the item
			whichList[parentXval][parentYval] = onClosedList;					//add the item to the closed list

			//	Open List = Binary Heap: Delete this item from the open list, which
			//  is maintained as a binary heap. For more information on binary heaps, see:

			numberOfOpenListItems = numberOfOpenListItems - 1;					//reduce number of open list items by 1

			//	Delete the top item in binary heap and reorder the heap, with the lowest F cost item rising to the top.
			openList[1] = openList[numberOfOpenListItems+1];					//move the last item in the heap up to slot #1
			v = 1;

			//	Repeat the following until the new item in slot #1 sinks to its proper spot in the heap.

			while (!GINPUT->KeyState(DIK_ESCAPE))								//reorder the binary heap
			{
				u = v;

				if (2*u+1 <= numberOfOpenListItems) //if both children exist
				{
	 				//Check if the F cost of the parent is greater than each child.
					//Select the lowest of the two children.
					if (Fcost[openList[u]] >= Fcost[openList[2*u]])
						v = 2*u;
					if (Fcost[openList[v]] >= Fcost[openList[2*u+1]])
						v = 2*u+1;
				}
				else
				{
					if (2*u <= numberOfOpenListItems) //if only child #1 exists
					{
	 				//Check if the F cost of the parent is greater than child #1
						if (Fcost[openList[u]] >= Fcost[openList[2*u]])
							v = 2*u;
					}
				}

				if (u != v) //if parent's F is > one of its children, swap them
				{
					temp = openList[u];
					openList[u] = openList[v];
					openList[v] = temp;
				}

				else
					break; //otherwise, exit loop

			}// while


			//7.Check the adjacent squares. (Its "children" -- these path children are similar, conceptually, to the binary heap children mentioned	above, but don't confuse them. They are different. imPath children
			//	are portrayed in Demo 1 with grey pointers pointing toward their parents.) Add these adjacent child squares to the open list for later consideration if appropriate (see various if statements below).
			for (b = parentYval-1; b <= parentYval+1; b++)
			{
				for (a = parentXval-1; a <= parentXval+1; a++)
				{

					//	If not off the map (do this first to avoid array out-of-bounds errors)
					if (a != -1 && b != -1 && a != mapX && b != mapZ)
					{
						//	If not already on the closed list (items on the closed list have
						//	already been considered and can now be ignored).
						if (whichList[a][b] != onClosedList)
						{
							//	If not a wall/obstacle square.
							if (walkability [a][b] != unwalkable)
							{
								//	Don't cut across corners
								corner = walkable;

								if (a == parentXval-1)
								{
									if (b == parentYval-1)
									{
										if (walkability[parentXval-1][parentYval] == unwalkable	|| walkability[parentXval][parentYval-1] == unwalkable)
											corner = unwalkable;
									}
									else if (b == parentYval+1)
									{
										if (walkability[parentXval][parentYval+1] == unwalkable	|| walkability[parentXval-1][parentYval] == unwalkable)
											corner = unwalkable;
									}
								}

								else if (a == parentXval+1)
								{
									if (b == parentYval-1)
									{
										if (walkability[parentXval][parentYval-1] == unwalkable	|| walkability[parentXval+1][parentYval] == unwalkable)
											corner = unwalkable;
									}
									else if (b == parentYval+1)
									{
										if (walkability[parentXval+1][parentYval] == unwalkable	|| walkability[parentXval][parentYval+1] == unwalkable)
											corner = unwalkable;
									}
								}



								if (corner == walkable)
								{
										//	If not already on the open list, add it to the open list.
									if (whichList[a][b] != onOpenList)
									{

										//Create a new open list item in the binary heap.
										newOpenListItemID += 1;					//each new item has a unique ID #
										m = numberOfOpenListItems+1;
										openList[m] = newOpenListItemID;		//place the new open list item (actually, its ID#) at the bottom of the heap
										openX[newOpenListItemID] = a;
										openY[newOpenListItemID] = b;			//record the x and z coordinates of the new item

										//Figure out its G cost
										if (abs(a-parentXval) == 1 && abs(b-parentYval) == 1)
											addedGCost = 14;//cost of going to diagonal squares
										else
											addedGCost = 10;//cost of going to non-diagonal squares

										Gcost[a][b] = Gcost[parentXval][parentYval] + addedGCost;

										//Figure out its H and F costs and parent
										Hcost[openList[m]] = 10*(abs(a - targetX) + abs(b - targetY));
										Fcost[openList[m]] = Gcost[a][b] + Hcost[openList[m]];
										
										parentX[a][b] = parentXval;
										parentY[a][b] = parentYval;

										//Move the new open list item to the proper place in the binary heap.
										//Starting at the bottom, successively compare to parent items,
										//swapping as needed until the item finds its place in the heap
										//or bubbles all the way to the top (if it has the lowest F cost).

										while (m != 1) //While item hasn't bubbled to the top (m=1)
										{
											//Check if child's F cost is < parent's F cost. If so, swap them.
											if (Fcost[openList[m]] <= Fcost[openList[m/2]])
											{
												temp = openList[m/2];
												openList[m/2] = openList[m];
												openList[m] = temp;
												m = m/2;
											}

											else
												break;
										}

										numberOfOpenListItems = numberOfOpenListItems+1;//add one to the number of items in the heap

										//Change whichList to show that the new item is on the open list.
										whichList[a][b] = onOpenList;
									}

									//8.If adjacent cell is already on the open list, check to see if this
									//	path to that cell from the starting location is a better one.
									//	If so, change the parent of the cell and its G and F costs.
									else //If whichList(a,b) = onOpenList
									{

										//Figure out the G cost of this possible new path
										if (abs(a-parentXval) == 1 && abs(b-parentYval) == 1)
											addedGCost = 14;//cost of going to diagonal tiles
										else
											addedGCost = 10;//cost of going to non-diagonal tiles

										tempGcost = Gcost[parentXval][parentYval] + addedGCost;

										//If this path is shorter (G cost is lower) then change
										//the parent cell, G cost and F cost.
										if (tempGcost < Gcost[a][b]) //if G cost is less,
										{
											parentX[a][b] = parentXval; //change the square's parent
											parentY[a][b] = parentYval;
											Gcost[a][b] = tempGcost;//change the G cost

											//Because changing the G cost also changes the F cost, if
											//the item is on the open list we need to change the item's
											//recorded F cost and its position on the open list to make
											//sure that we maintain a properly ordered open list.
											for (INT x = 1; x <= numberOfOpenListItems; ++x) //look for the item in the heap
											{
												if (openX[openList[x]] == a && openY[openList[x]] == b) //item found
												{
													Fcost[openList[x]] = Gcost[a][b] + Hcost[openList[x]];//change the F cost

													//See if changing the F score bubbles the item up from it's current location in the heap
													m = x;

													while (m != 1) //While item hasn't bubbled to the top (m=1)
													{
														//Check if child is < parent. If so, swap them.
														if (Fcost[openList[m]] < Fcost[openList[m/2]])
														{
															temp = openList[m/2];
															openList[m/2] = openList[m];
															openList[m] = temp;
															m = m/2;
														}
														else
															break;
													}

													break; //exit for x = loop
												} //If openX(openList(x)) = a

											} //For x = 1 To numberOfOpenListItems
										}//If tempGcost < Gcost(a,b)

									}//else If whichList(a,b) = onOpenList
								}//If not cutting a corner


							}//If not a wall/obstacle square.
						}//If not already on the closed list
					}//If not off the map
				}//for (a = parentXval-1; a <= parentXval+1; a++){
			}//for (b = parentYval-1; b <= parentYval+1; b++){

		}//if (numberOfOpenListItems != 0)

		//9.If open list is empty then there is no path.
		else
		{
			path = nonexistent;
			break;
		}


		//If target is added to open list then path has been found.
		if (whichList[targetX][targetY] == onOpenList)
		{
			path = found;
			break;
		}

	}// While


	//10.Save the path if it exists.
	if (path == found)
	{
		//a.Working backwards from the target to the starting location by checking
		//	each cell's parent, figure out the length of the path.

		pathX = targetX;
		pathY = targetY;

		while (pathX != startX || pathY != startY)
		{
			//Look up the parent of the current cell.
			tempx = parentX[pathX][pathY];
			pathY = parentY[pathX][pathY];
			pathX = tempx;

			//Figure out the path length
			pathLength = pathLength + 1;
		}

		//b.Resize the data bank to the right size in bytes
		pathBank = (INT*) realloc (pathBank, pathLength*8);

		//c. Now copy the path information over to the databank. Since we are
		//	working backwards from the target to the start location, we copy
		//	the information to the data bank in reverse order. The result is
		//	a properly ordered set of path data, from the first step to the
		//	last.

		pathX = targetX ;
		pathY = targetY;
		cellPosition = pathLength*2;//start at the end

		while (pathX != startX || pathY != startY)
		{
			cellPosition = cellPosition - 2;//work backwards 2 integers
			pathBank[cellPosition] = pathX;
			pathBank[cellPosition+1] = pathY;

			//d.Look up the parent of the current cell.
			tempx = parentX[pathX][pathY];
			pathY = parentY[pathX][pathY];
			pathX = tempx;

			//e.If we have reached the starting square, exit the loop.
		}
	}

	return path;

//13.If there is no path to the selected target, set the pathfinder's
//	xPath and yPath equal to its current location and return that the
//	path is nonexistent.
noPath:

	return nonexistent;
}


// Desc: Reads path data created by FindPath()
void CPathFind::ReadPath()														//If a path exists, read the path data from the pathbank.
{
	pathLocation = 1;															//set pathLocation to 1st step

	while (pathLocation < pathLength)
	{
		INT x = pathBank[pathLocation*2 - 2];
		INT z = pathBank[pathLocation*2 - 1];
		pathLocation = pathLocation + 1;
		whichList[x][z] = 3;													//draw dotted path
	}
}


INT CPathFind::DrawBlock (Image* pImage, INT x, INT z)
{
	RECT rectDest= {0,0, pImage->imageWidth, pImage->imageHeight};
	HRESULT hr = GSPRITE->Draw(pImage->pSurface, &rectDest, NULL, NULL, 0, &VEC2(x, z), XCLR(1,1,1,1));
	return hr;
}


// Desc: Draws stuff on screen
void CPathFind::Render()
{
	DrawBlock (m_pImGreen,startX*tileS,startY*tileS);							//Draw starting location
	DrawBlock (m_pImRed,targetX*tileS, targetY*tileS);							//Draw target location

	for (INT x=0; x<mapX; ++x)													//draw each of 16 tiles across the screen
	{
		for (INT z=0; z<mapZ; ++z)												//draw each of 12 tiles down the screen
		{
			if (walkability[x][z] == unwalkable)								//Draw blue walls
				DrawBlock(m_pImWall,x*tileS, z*tileS);

			if (whichList[x][z] == 3)											//Draw cells on open list (green), closed list (blue) and part of the found path, if any (red dots).
				DrawBlock (m_pImPath,x*tileS, z*tileS);

			//Print F, G and H costs in cells
			if (whichList[x][z] > 0) //if an open, closed, or path cell.
			{
				INT G = Gcost[x][z];
				INT H = 10*(abs(x - targetX) + abs(z - targetY));
				INT F = G + H;
			}
		}
	}

//	VEC2 Line[2];
//	Line[0] =VEC2(   0, 300);
//	Line[1] =VEC2(1000, 300);
//
//	m_pLine->Begin();
//
//	FLOAT	MaxX = tileS* mapX;
//	FLOAT	MaxZ = tileS* mapZ;
//
//	for(INT i=0; i<=mapX; ++i)
//	{
//		for(INT j=0; j<=mapZ; ++j)
//		{
//			Line[0] =VEC2( i*tileS, 0);
//			Line[1] =VEC2( i*tileS, MaxZ);
//
//			m_pLine->Draw(Line, 2, 0xff00ffff);
//
//			Line[0] =VEC2(    0, j*tileS);
//			Line[1] =VEC2( MaxX, j*tileS);
//
//			m_pLine->Draw(Line, 2, 0xff00ffff);
//		}
//	}
//
//	m_pLine->End();
}


INT CPathFind::FrameMove()
{
//	if (MouseDown(1) == 0 && MouseDown(2) == 0)
//		drawing = 0;
//	if (MouseDown(1) == 0 && MouseDown(2) == 0)
//		erasing = 0;

	INT MouseX = GMOUSEPOS.x/tileS;
	INT MouseY = GMOUSEPOS.y/tileS;

	//Draw and Erase walls (blue squares)
	if(	GINPUT->ButtonState(0) && !( GINPUT->KeyState(DIK_G) || GINPUT->KeyState(DIK_T) )
		)//if not "g"  or "t" key
	{
		//Draw walls
		if (walkability[MouseX][MouseY]	== walkable && erasing == 0)
		{
	 		walkability[MouseX][MouseY] = unwalkable;
			drawing = 1;
		}

		//Erase walls
		if (walkability[MouseX][MouseY]	== unwalkable && drawing == 0)
		{
	 		walkability[MouseX][MouseY] = walkable;
			erasing = 1;
		}
	}

	//Move red target square around
	if (GINPUT->KeyState(DIK_T) && GINPUT->ButtonDown(0))
	{
		targetX = MouseX;
		targetY = MouseY;
	}

	//Move green starting square around
	else if (GINPUT->KeyState(DIK_G) && GINPUT->ButtonDown(0))
	{
		startX = MouseX;
		startY = MouseY;
	}

	//Start A* pathfinding search if return/enter key is hit
	if (path == notfinished)
	{
		//if path not searched
		if (GINPUT->KeyState(DIK_RETURN))
		{
			path=FindPath(startX*tileS,startY*tileS,targetX*tileS,targetY*tileS);

			if (path == found)
				ReadPath();

			whichList[startX][startY] = 0;//don't highlight the start square (aesthetics)
		}
	}

	if (path == notfinished)
	{
		//if path not searched
	}



	if(GINPUT->GetKey(DIK_SPACE))
		Set();

	return 1;
}



Image* CPathFind::TextureLoad (char* szBitmap)
{
	XIMG	pInf;
	Image* pImage = new Image;
	SeUtil_TextureLoad(szBitmap, pImage->pSurface, 0xffffffff, &pInf);			//Create a new Image class instance to hold image data

	pImage->imageWidth = pInf.Width;
	pImage->imageHeight = pInf.Height;

	return pImage;
}
