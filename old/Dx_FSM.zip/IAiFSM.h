// IAiFSM.h: interface for the IAiFSM class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _IAIFSM_H_
#define _IAIFSM_H_



// FMS State
enum EFsmSt
{
	FSM_REGEN= 0X0,
	FSM_IDLE= 0X1,
	FSM_WEAV,
	FSM_ATTACK,
	FSM_DAMAGE,
	FSM_DEAD,
	FSM_TOT,
};

class IAiFSM  
{
protected:
	LPDIRECT3DTEXTURE9	m_pTx;
	LPDIRECT3DTEXTURE9	m_pTxR;
	LPDIRECT3DTEXTURE9	m_pTxG;
	LPDIRECT3DTEXTURE9	m_pTxB;

public:
	EFsmSt			m_eSt;
	D3DXVECTOR2		m_vcDir;
	D3DXVECTOR2		m_vcPos;
	FLOAT			m_fSpd;
public:
	IAiFSM();
	virtual ~IAiFSM();

	virtual	void	OnRegen();
	virtual	void	OnIdle();
	virtual	void	OnWeaving();
	virtual	void	OnAttack();
	virtual	void	OnDamage();
	virtual	void	OnDead();

	virtual	INT		Init();
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();


	void	SetSt(INT eSt);
	void	SetPos(D3DXVECTOR2 vcPos);
	void	SetDir(D3DXVECTOR2 vcPos);
	void	SetSpd(FLOAT fSpd);
};

#endif
