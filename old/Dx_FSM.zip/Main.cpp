// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	strcpy(m_sWin, "FSM Simulator");

	m_pInput			= NULL;
	m_dScnX				= 1024;
	m_dScnY				= 768;
}

CMain::~CMain()
{

}


HRESULT CMain::Init()
{
	m_pInput = new CMcInput;
	m_pInput->Init();

	LOGFONT hFnt= {18, 0, 0, 0, 100, 0, 0, 0, 0, 0, 2, 1, VARIABLE_PITCH | FF_ROMAN, "Arial"};
	D3DXCreateFontIndirect(GDEVICE, &hFnt, &m_p3dFnt);



	for(int i=0; i<MAX_AI; ++i)
	{
		FLOAT fAngle = FLOAT(rand()%360);
		D3DXVECTOR2 vcPos( 100.f + rand()%824, 100.f +rand()%568);
		D3DXVECTOR2 vcDir( cosf(D3DXToRadian(fAngle)), sinf(D3DXToRadian(fAngle)));
		

		FLOAT	fSpd = (100+rand()%300) * 0.01f;

		EFsmSt	eSt = EFsmSt(rand()%FSM_TOT);

		m_pAi[i] = new IAiFSM;
		m_pAi[i]->Init();
		
		m_pAi[i]->SetSt(eSt);
		m_pAi[i]->SetPos(vcPos);
		m_pAi[i]->SetDir(vcDir);
		m_pAi[i]->SetSpd(fSpd);
	}


	return 1;
}



HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_p3dFnt	);
	SAFE_DELETE(	m_pInput	);	

	return 1;
}



HRESULT CMain::FrameMove()
{
	if(m_pInput)
		m_pInput->FrameMove();


	for(int i=0; i<MAX_AI; ++i)
	{
		m_pAi[i]->FrameMove();
	}

	return 1;
}






HRESULT CMain::Render()
{
	if( NULL == m_pd3dDevice )
		return -1;
	
	m_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
	

	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;


	for(int i=0; i<MAX_AI; ++i)
	{
		m_pAi[i]->Render();
	}


	m_p3dFnt->Begin();

	RECT	rt	= { 10, 0, m_dScnX-10, 50};
	TCHAR	sMsg[128];

	sprintf(sMsg, "FSM Simulator");

	m_p3dFnt->DrawText(sMsg, -1, &rt, 0, D3DXCOLOR(1,1,0,1));
	m_p3dFnt->End();
	
	
	// EndScene
	m_pd3dDevice->EndScene();
	
	return 1;
}







LRESULT CMain::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_MOUSEWHEEL:
		{
			INT c= HIWORD(wParam);
			INT d= LOWORD(wParam);

			m_pInput->AddZ( short( HIWORD(wParam) ) );

			if(d)
			{
				m_pInput->SetMouseSt(6, true);
			}
			else
			{
				m_pInput->SetMouseSt(6, false);
			}

			return 0;
		}


		case WM_LBUTTONDOWN	:
		{
			m_pInput->SetMouseSt(0, true);
			return 0;
		}
		case WM_LBUTTONUP:
		{
			m_pInput->SetMouseSt(1, true);
			return 0;
		}
		case WM_LBUTTONDBLCLK:
		{
			m_pInput->SetMouseSt(2, true);
			return 0;
		}

		case WM_RBUTTONDOWN	:
		{
			m_pInput->SetMouseSt(3, true);
			return 0;
		}
		case WM_RBUTTONUP:
		{
			m_pInput->SetMouseSt(4, true);
			return 0;
		}
		case WM_RBUTTONDBLCLK:
		{
			m_pInput->SetMouseSt(5, true);
			return 0;
		}

		case WM_MBUTTONDOWN	:
		{
			m_pInput->SetMouseSt(6, true);
			return 0;
		}
		case WM_MBUTTONUP:
		{
			m_pInput->SetMouseSt(7, true);
			return 0;
		}
		case WM_MBUTTONDBLCLK:
		{
			m_pInput->SetMouseSt(8, true);
			return 0;
		}
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




HRESULT CMain::SpriteDraw(LPDIRECT3DTEXTURE9  pSrcTexture
						, RECT* pSrcRect
						, D3DXVECTOR2* pScaling
						, D3DXVECTOR2* pRotationCenter
						, FLOAT Rotation
						, D3DXVECTOR2* pTranslation, D3DCOLOR Color)
{
	return m_pd3dSprite->Draw(pSrcTexture, pSrcRect, pScaling, pRotationCenter, Rotation, pTranslation, Color);
}