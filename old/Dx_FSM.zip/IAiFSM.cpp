// IAiFSM.cpp: implementation of the IAiFSM class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


IAiFSM::IAiFSM()
{
	m_pTx	= NULL;
	m_pTxR	= NULL;
	m_pTxG	= NULL;
	m_pTxB	= NULL;

	m_fSpd	= 0.f;
}

IAiFSM::~IAiFSM()
{
	Destroy();
}

INT IAiFSM::Init()
{
	McUtil_TextureLoad("Texture/red.png", &m_pTxR);
	McUtil_TextureLoad("Texture/Green.png", &m_pTxG);
	McUtil_TextureLoad("Texture/blue.png", &m_pTxB);
	m_pTx = m_pTxG;

	return 1;
}

void IAiFSM::Destroy()
{
	SAFE_RELEASE(	m_pTxR	);
	SAFE_RELEASE(	m_pTxG	);
	SAFE_RELEASE(	m_pTxB	);
}

INT IAiFSM::FrameMove()
{
	switch(m_eSt)
	{
	case FSM_REGEN:
		OnRegen();
		break;

	case FSM_IDLE:
		OnIdle();
		break;

	case FSM_WEAV:
		OnWeaving();
		break;

	case FSM_ATTACK:
		OnAttack();
		break;

	case FSM_DAMAGE:
		OnDamage();
		break;

	case FSM_DEAD:
		OnDead();
		break;

	default:
		OnIdle();
	}

	return 1;
}


void IAiFSM::Render()
{
	RECT rc={0,0, 8, 8};
	GMAIN->SpriteDraw(m_pTx, &rc, NULL, NULL, 0, &m_vcPos);
}



void IAiFSM::SetSt(INT eSt)
{
	m_eSt = (EFsmSt)eSt;
}


void IAiFSM::SetPos(D3DXVECTOR2 vcPos)
{
	m_vcPos = vcPos;
}

void IAiFSM::SetDir(D3DXVECTOR2 vcDir)
{
	m_vcDir = vcDir;
}

void IAiFSM::SetSpd(FLOAT fSpd)
{
	m_fSpd = fSpd;
}


void IAiFSM::OnRegen()
{
}

void IAiFSM::OnIdle()
{
	m_pTx = m_pTxG;
}

void IAiFSM::OnWeaving()
{
	m_vcPos+=m_vcDir* m_fSpd;
}

void IAiFSM::OnAttack()
{
	m_pTx = m_pTxR;
}

void IAiFSM::OnDamage()
{
	m_pTx = m_pTxB;
}

void IAiFSM::OnDead()
{
}

