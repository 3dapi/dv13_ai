// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_

#define MAX_AI	100

class CMain : public CD3DApplication  
{
protected:
	CMcInput*		m_pInput	;
	LPD3DXFONT		m_p3dFnt	;

	IAiFSM*			m_pAi[MAX_AI];

public:
	CMain();
	virtual ~CMain();


	virtual	HRESULT	Init();														// Game Data ����
	virtual	HRESULT	Destroy();													// Game Data �Ҹ�
	virtual	HRESULT	FrameMove();												// Game Data ����
	virtual	HRESULT	Render();													// Game Data �׸���

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);


	HRESULT SpriteDraw(LPDIRECT3DTEXTURE9	pSrcTexture
						, RECT*				pSrcRect
						, D3DXVECTOR2*		pScaling  = NULL
						, D3DXVECTOR2*		pRotCenter= NULL
						, FLOAT				Rotation  = 0
						, D3DXVECTOR2*		pTransn   = NULL
						, D3DCOLOR			Color	  = 0xFFFFFFFF);
};


extern	CMain*	g_pApp;

#endif